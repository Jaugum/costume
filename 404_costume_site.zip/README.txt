
# 404 Costume Not Found — mini-nettside

Dette er en enkel, statisk side (én `index.html`) du kan hoste gratis.

## Alternativ A — GitHub Pages (anbefalt, gratis)

1) Lag et nytt repo på GitHub kalt `costume-404` (public).
2) Last opp `index.html` (filen i denne ZIP-en).
3) Gå til **Settings → Pages**.
   - Under **Build and deployment**, sett **Source** til `Deploy from a branch`.
   - Sett **Branch** til `main` og **/ (root)`.
4) Vent 1–2 minutter. Siden blir tilgjengelig på:  
   `https://<ditt-brukernavn>.github.io/costume-404/`

## Alternativ B — Netlify Drop (superenkelt)

1) Gå til Netlify Drop (søk "Netlify Drop").
2) Dra og slipp mappen med `index.html`.  
3) Du får en URL som ligner `https://brave-brown-12345.netlify.app`.

---

## Lag QR-kode for utskrift

Når du har den endelige URL-en, kan du gjøre ett av disse:

### 1) La ChatGPT lage QR-koden
Svar meg her med URL-en, så genererer jeg en utskriftsklar PDF/PNG i flere størrelser.

### 2) Lag lokalt (Python)
Hvis du har Python:
```bash
pip install qrcode[pil] pillow
python - << 'PY'
import qrcode
url = "https://example.com/your-404"   # ← bytt til din URL
img = qrcode.make(url)
img.save("qr_costume_404.png")
print("Saved qr_costume_404.png")
PY
```

Skriv ut og teip QR-en på lappen — ferdig kostyme 😄
